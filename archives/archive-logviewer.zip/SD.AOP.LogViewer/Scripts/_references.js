﻿/// <reference path="jquery-1.12.4.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="knockout-2.2.0.debug.js" />
/// <reference path="/EasyUI/jquery.easyui.min.js" />
/// <reference path="/EasyUI/jquery.easyui.GlobalParas.js" />
/// <reference path="jquery.messageBox.js" />
